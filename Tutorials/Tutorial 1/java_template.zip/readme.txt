We provide a java program template in "Solution.java" to get you quickly familiar with java, which follows the structure introduced in tut1.
Program under this structure can be compiled and run on the Online Judge System of CUHK(SZ).

Remember, this is just an optional program structure, and you are free to choose your own coding style in your assignments.

If you are confused about the meaning of this program, you can refer to "Solution.py" or "Solution-static.py", which are writen in Python and equivalent in meaning to the "Solution.java".

by jdr & htc